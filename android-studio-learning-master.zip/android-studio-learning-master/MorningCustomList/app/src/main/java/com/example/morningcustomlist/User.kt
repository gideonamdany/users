package com.example.morningcustomlist

data class User (var image:Int, var name:String, var number:String)